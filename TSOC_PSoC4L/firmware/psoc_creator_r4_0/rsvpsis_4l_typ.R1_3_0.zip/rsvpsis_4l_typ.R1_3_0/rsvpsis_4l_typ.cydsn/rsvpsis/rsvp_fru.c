/**
 ******************************************************************************
    @file        rsvp_fru.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the rsvp_FRU hardware porting/mapping routines
    @section     rsvp_FRU_intro rsvp_FRU hardware porting/mapping
    @par
    The "rsvp_FRU" encapsulates all the hardware "metadata" into a linked structure. \n
    The "rsvp_FRU" structure can be exposed via I2C, SPI or UART interfaces. \n
	
    @section    rsvp_FRU_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_fru.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU rsvp_FRU
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/
/* rsvp_fru_bmc - Baseboard Management Controller - Field Replaceable Unit     */
/*-----------------------------------------------------------------------------*/
/* This FRU array is typically 512 bytes long and it's data is returned        */
/* (by default) as the base of the exposed device register/address space.      */
/* If a Multirecord area is required, it will occupy the second 256 byte page. */
/*                                                                             */
/* This FRU is a valid, but simplified FRU format, we shall refer to as        */
/* the "Canonical FRU format". In this format, all fields are populated        */
/* with their maximum recommended field size, and that field is null-padded    */
/* (with zeros) to fill a fixed size and hence have fixed locations in memory. */
/* The "Canonical FRU format" is 256 bytes long, with an additional 256 bytes  */
/* reserved for a Multirecord area to contain power supply information, and    */
/* initial device provisioning information, such as MAC ID, Gateway Address,   */
/* DNS address, "Home" URL, "Update" URL, and others. Usually 512 bytes is     */
/* sufficient to hold all the device "metadata", however if more space is      */
/* required, the field can be expanded up to 4K bytes in practice.             */
/* if a number of motor profile or other local calibration tables are needed,  */
/* then the size of the FRU area may need to expand beyond the reserved size   */
/* of 512 bytes (default).                                                     */                    
/*                                                                             */
/* This allows simple access to the FRU from the firmware using fixed offsets. */
/* ANY user writes to this FRU MUST conform to "Canonical FRU Format", and     */
/* those user writes must update any field related checksums manually.         */
/*                                                                             */
/* In order to save device flash memory space, it is assumed that the host     */
/* FRU update process is to enforce the padding, that logic is too large to    */
/* embed here locally. The flash write routines are "blind" updates.           */
/*                                                                             */
/* This array is placed in flash and uses the "CYCODE" keyword so that this    */
/* array can be placed within the em_EEPROM component and simulate an EEPROM.  */
/*                                                                             */
/* Note: This is a default "blank" template, see http://www.rsvpsis.org for    */
/*       examples of complete FRU tables for sample products                   */
/*                                                                             */
/* @TODO: add "PSOC" guards for special creator keywords for portability.      */
/*                                                                             */
rsvp_cu8_t CYCODE rsvp_fru_bmc[RSVP_FRU_PDU_LENGTH] = {
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       FRU Common Header                                     [  8] bytes */
    0x01, /* Common Header Format Version = 1                                  */
    0x01, /* Internal Use Area Offset                              { 72} bytes */
	0x0A, /* Chassis Info Area Offset                              { 32} bytes */
	0x0E, /* Board Info Area Offset                                { 64} bytes */
	0x16, /* Product Info Area Offset                              { 96} bytes */
	0x22, /* MultiRecord Info Starting Area                        {240} bytes */
	0x00, /* Padding, always 0x00                                              */
	0x00, /* Common Header Checksum                                            */
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Internal Use Area : Application Defined Data Area of  [ 72] bytes */
	/*       Internal Use Area : Header Area and 64 byte Data Area             */
	0x01, /* Internal Use Area : Format = 1                                    */
	0x09, /* Internal Use Area : Length (in multiples of 8 bytes)  [ 72] bytes */
	0x00, /* Internal Use Area : IUA_Flag_1                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_2                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_3                        [  1] byte  */
	0x00, /* Internal Use Area : IUA_Flag_4                        [  1] byte  */
	0x00, /* Internal Use Area : Header Checksum                               */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* Data Area   [ 64] bytes */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* Make & Model Parameters */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* This data in this area  */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* is product specific ... */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, /* User/Application Data   */
	0x00, /* Internal Use Area : Internal Use Area Checksum                    */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Chassis Info :                                        [ 32] bytes */
	0x01, /* Chassis Info : Format = 1                                         */
	0x04, /* Chassis Info : Length (in multiples of 8 bytes)       { 32} bytes */
	0x15, /* Chassis Info : Type (enumeration) 0x15 = Peripheral Chassis       */
    0xCC, /* Chassis Info : Part Number (type/length) (ascii/12 bytes)         */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
    0xCC, /* Chassis Serial Number (type/length) (ascii/12 bytes)              */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xC1, /* Chassis Info Area : (type/length byte - no more info fields)      */	
	0x00, /* Chassis Info Area : Chassis Info Checksum                         */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Board Info :                                          [ 64] bytes */
	0x01, /* Board Info : Format = 1                                           */
	0x08, /* Board Info : Length (in multiples of 8 bytes)         { 64} bytes */
	0x00, /* Board Info : Language code (section 15)                           */
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(lsb)*/
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(csb)*/
	0x00, /* Board Info : Board Mfg.Date # of minutes from 0:00 hrs 1/1/96(msb)*/
	0xCC, /* Board Info : Board Mfg.Name (type/length) (ascii/12 bytes)        */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Name (type/length) (ascii/12 bytes)            */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Serial Number (type/length) (ascii/12 bytes)   */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Board Info : Board Part Number (type/length) (ascii/12 bytes)     */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xC0, /* Board Info : Board FRU File ID (type/length) (not used)           */
	0xC1, /* Board Info : (type/length byte - no more info fields)             */	
	0x00, /* Board Info : Board Info Padding1                                  */ 
	0x00, /* Board Info : Board Info Padding2                                  */ 
	0x00, /* Board Info : Board Info Padding3                                  */ 
	0x00, /* Board Info : Board Info Checksum                                  */ 
	/*                                                                         */
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*       Product Info :                                        [ 96] bytes */
	0x01, /* Product Info : Format = 1                                         */
	0x0C, /* Product Info : Length (in multiples of 8 bytes)       { 96} bytes */
	0x00, /* Product Info : Language Code (See section 15)                     */
	0xCC, /* Product Info : Mfg. Name (type/length) (ascii/12 bytes)           */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Name (type/length) (ascii/12 bytes)        */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Model (type/length) (ascii/12 bytes)       */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Version (type/length) (ascii/12 bytes)     */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xCC, /* Product Info : Product Serial # (type/length) (ascii/12 bytes)    */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	0xD4, /* Product Info : Product Asset Tag (type/length) (ascii/20 bytes)   */
	' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '
 };
	//' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
	//0xC0, /* Product Info : FRU File ID (C0 = Not Used)                        */
	//0xC1, /* Product Info : (type/length byte - no more info fields)           */	
	//0x00, /* Product Info : Product Info Padding1                              */ 
	//0x00, /* Product Info : Product Info Padding2                              */ 
	//0x00, /* Product Info : Product Info Padding3                              */ 
	//0x00, /* Product Info : Product Info Padding4                              */ 
	//0x00, /* Product Info : Product Info Checksum                              */ 
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
	/*  MultiRecord Area :                                        [ 240] bytes */
	/*  (empty for now, can contain configuration URL information)             */
	/*                                                                         */
	//0
	/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
//};

rsvp_cu32_t       	rsvp_FRU_PDU_Size =  RSVP_FRU_PDU_LENGTH;

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of rsvp_FRU.c */

