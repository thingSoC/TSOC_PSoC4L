/*****************************************************************************
  * @file        rsvp_FRU.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define the IPMI FRU 
                 (Field Replaceable Unit)
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_FRU_H_
#define RSVP_FRU_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>

/** @addtogroup rsvp_FRU rsvp_FRU
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU_Exported_Types
  * @{
  */
struct rsvp_fru_common_header_t {
            rsvp_u8_t  format;                 /* 0x01 */
            rsvp_u8_t  internal_use_offset;    /* multiple of 8 bytes */
            rsvp_u8_t  chassis_info_offset;    /* multiple of 8 bytes */
            rsvp_u8_t  board_area_offset;      /* multiple of 8 bytes */
            rsvp_u8_t  product_area_offset;    /* multiple of 8 bytes */
            rsvp_u8_t  multirecord_offset;     /* multiple of 8 bytes */
            rsvp_u8_t  padding;                /* must be 0 */
            rsvp_u8_t  checksum;               /* sum modulo 256 must be 0 */
};

/**
  * Close the Doxygen rsvp_FRU_Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU_Exported_Constants
  * @{
  */

/* FRU Configuration Default                                                   */
/* Note Bene : Uses Fixed Offsets that must be maintained !!!                  */
/*             These offsets MUST match the FRU Common Header Offsets exactly! */
//#define RSVP_FRU_PDU_LENGTH                            (  512 )
#define RSVP_FRU_PDU_LENGTH                            (  256 )
#define RSVP_FRU_PDU_COMMON_HEADER_OFFSET              (    0 )

/*  Internal Use Area                                                          */
#define RSVP_FRU_PDU_CANON_IUA_OFFSET                  (    8 )
#define RSVP_FRU_PDU_CANON_IUA_FLAG_1_OFFSET           RSVP_FRU_PDU_CANON_IUA_OFFSET+2
#define RSVP_FRU_PDU_CANON_IUA_FLAG_2_OFFSET           RSVP_FRU_PDU_CANON_IUA_OFFSET+3
#define RSVP_FRU_PDU_CANON_IUA_FLAG_3_OFFSET           RSVP_FRU_PDU_CANON_IUA_OFFSET+4
#define RSVP_FRU_PDU_CANON_IUA_FLAG_4_OFFSET           RSVP_FRU_PDU_CANON_IUA_OFFSET+5
#define RSVP_FRU_PDU_CANON_IUA_HCHKSUM_OFFSET          RSVP_FRU_PDU_CANON_IUA_OFFSET+6
#define RSVP_FRU_PDU_CANON_IUA_DATA_OFFSET             RSVP_FRU_PDU_CANON_IUA_OFFSET+7
#define RSVP_FRU_PDU_CANON_IUA_CHKSUM_OFFSET           RSVP_FRU_PDU_CANON_IUA_OFFSET+71

/*  Chassis Info Area                                                           */
#define RSVP_FRU_PDU_CANON_CHASSIS_OFFSET              (    80 )
#define RSVP_FRU_PDU_CANON_CHASSIS_PARTNUM_OFFSET      RSVP_FRU_PDU_CANON_CHASSIS_OFFSET+4
#define RSVP_FRU_PDU_CANON_CHASSIS_PARTNUM_LENGTH      (    12 )
#define RSVP_FRU_PDU_CANON_CHASSIS_SERNUM_OFFSET       RSVP_FRU_PDU_CANON_CHASSIS_OFFSET+17
#define RSVP_FRU_PDU_CANON_CHASSIS_SERNUM_LENGTH       (    12 )

/*  Board Info Area                                                             */
#define RSVP_FRU_PDU_CANON_BRD_OFFSET                  (   112 )

#define RSVP_FRU_PDU_CANON_PRD_OFFSET                  (   176 )

#define RSVP_FRU_PDU_CANON_MRA_OFFSET                  (   272 )


/* canonical FRU recommended structure */
/* N.B. - Fixed (maximum) Field Sizes for each field */

/**
  * Close the Doxygen rsvp_FRU_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_FRU_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU_Exported_Variables 
  * @{
  */
extern rsvp_cu8_t           rsvp_fru_bmc[RSVP_FRU_PDU_LENGTH];
extern rsvp_cu32_t       	rsvp_FRU_PDU_Size;

/**
  * Close the Doxygen rsvp_FRU_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_FRU_Exported_Functions
  * @{
  */

/**
  * Close the Doxygen rsvp_FRU_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_FRU_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_FRU group.
  *    @}
*/



