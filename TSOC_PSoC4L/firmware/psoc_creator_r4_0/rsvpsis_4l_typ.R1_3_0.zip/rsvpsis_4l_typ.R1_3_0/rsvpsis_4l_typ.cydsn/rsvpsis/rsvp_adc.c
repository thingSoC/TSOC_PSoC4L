/**
 ******************************************************************************
    @file        rsvp_adc.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the rsvp_adc Analog-to-Digital Converter routines.
    @section     rsvp_adc_intro rsvp_adc hardware routines
    @par	
    @section    rsvp_adc_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_adc.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc rsvp_adc
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/

/**
  * @fn         rsvp_RetCode_t rsvp_platform_PollADC(void)
  * @brief      get an ADC channel reading
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_ADC_Poll(void)
{
  #if (RSVP_USE_ADC_1 == TRUE)
 // rsvp_u8_t channum;
	/* if the ADC conversion is done... */
    if (adc_1_irq_flag != 0u) {	
        /* Check for ADC window limit interrupt */
        if(adc_1_range_flag != 0u)
        {
            /* input is outside the voltage window (250mV - 750mV) */
			/* add error handler here                              */
        }
		adc_1_irq_flag = 0;
		/* do anything else when ADC data is ready? */
	}
  #endif
	return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of rsvp_adc.c */

