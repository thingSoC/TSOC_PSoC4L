/**
 ******************************************************************************
    @file        rsvp_ringbuf.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the rsvp ring buffer functions.
    @section     rsvp_ringbuf_intro rsvp_ringbuf hardware routines
    @par	
    @section    rsvp_ringbuf_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_platform.h>
#include <rsvp_ringbuf.h>
#include <assert.h>

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_ringbuf_UpdateIndex( rsvp_vu32_t *Buf_Value, rsvp_u32_t Buf_Delta, rsvp_u32_t Buf_Size)
  * @brief      Updates the Ring Index Value in Critical Context
  * @param      Ring Buffer Index
  * @retval     none
  * @detail
    Change the value of a variable in critical context.
   \param Buf_Value points to the index whose value is to be modified.
   \param Buf_Delta is the number of bytes to increment the index by.
   \param Buf_Size is the size of the buffer the index refers to.

  */
static void
rsvp_ringbuf_UpdateIndex( rsvp_vu32_t *Buf_Value, rsvp_u32_t Buf_Delta, rsvp_u32_t Buf_Size) 
{
     /* save the interurpt flags */
    bool rsvp_InterruptFlags;
    rsvp_InterruptFlags = CyEnterCriticalSection();
    
    /* Update the variable value */
    *Buf_Value += Buf_Delta;

    // Correct for buffer wraparound.
    while(*Buf_Value >= Buf_Size) {
        *Buf_Value -= Buf_Size;
    }

    /* Restore the interrupt flags */
    if(!rsvp_InterruptFlags) {
        CyExitCriticalSection(rsvp_InterruptFlags);
    }
}


/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufInit(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size)
  * @brief      Initialize the ring buffer object, preparing it to store data.
  * @param      Ring Buffer Structure
  * @retval     rsvp_u32_t
  * @detail
    Change the value of a variable in critical context.
    \param RingBuf_s points to the ring buffer structure to be initialized.
    \param Buf points to the data buffer to be used for the ring buffer.
    \param Buf_Size is the size of the buffer in bytes.
  */
void 
rsvp_RingBufInit(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size) {

    #if defined(RSVP_TEST)
      /* Check the arguments */
      assert(RingBuf_s != NULL);
      assert(Buf != NULL);
      assert(Buf_Size != 0);
    #endif

    /* Init the ring buffer object */
    RingBuf_s->Buf_Size = Buf_Size;
    RingBuf_s->Buf = Buf;
    RingBuf_s->Buf_WriteIndex = RingBuf_s->Buf_ReadIndex = 0;
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_isRingBufFull(rsvp_RingBuf_t *RingBuf_s)
  * @brief      test is the ringbuffer is full or not
  * @param      Ring Buffer Structure
  * @retval     bool
  * @detail
  */
bool
rsvp_isRingBufFull(rsvp_RingBuf_t *RingBuf_s)
{
    rsvp_u32_t tmpWrite;
    rsvp_u32_t tmpRead;

    #if defined(RSVP_TEST)
    assert(RingBuf_s != NULL);
    #endif

    /* Copy the Read/Write indices for calculation */
   tmpWrite = RingBuf_s->Buf_WriteIndex;
    tmpRead = RingBuf_s->Buf_ReadIndex;

    /* Return the status of the buffer (TRUE/FALSE) */
    return((((tmpWrite + 1) % RingBuf_s->Buf_Size) ==tmpRead) ? TRUE : FALSE);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_isRingBufEmpty(rsvp_RingBuf_t *RingBuf_s)
  * @brief      tests if the rung buffer is empty
  * @param      Ring Buffer Structure
  * @retval     bool
  * @detail
 */
bool
rsvp_isRingBufEmpty(rsvp_RingBuf_t *RingBuf_s)
{
    rsvp_u32_t tmpWrite;
    rsvp_u32_t tmpRead;

    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
    #endif

    /* Copy the Read/Write indexs */
    tmpWrite = RingBuf_s->Buf_WriteIndex;
    tmpRead = RingBuf_s->Buf_ReadIndex;

    /* Return the empty status of the buffer */
    return((tmpWrite == tmpRead) ? TRUE : FALSE);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufFlush(rsvp_RingBuf_t *RingBuf_s)
  * @brief      Flush/Empty the ring buffer
  * @param      Ring Buffer Structure
  * @retval     bool
  * @detail
 */
void
rsvp_RingBufFlush(rsvp_RingBuf_t *RingBuf_s)
{
    bool rsvp_InterruptFlags;

    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
    #endif
    
    /* Set Read/Write pointers to be equal */ 
    rsvp_InterruptFlags = CyEnterCriticalSection();
    RingBuf_s->Buf_ReadIndex = RingBuf_s->Buf_WriteIndex;
    if (!rsvp_InterruptFlags) {
      CyExitCriticalSection(rsvp_InterruptFlags);
    }
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufUsed(rsvp_RingBuf_t *RingBuf_s)
  * @brief      bytes used in the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     rsvp_u32_t
  * @detail
 */
rsvp_u32_t
rsvp_RingBufUsed(rsvp_RingBuf_t *RingBuf_s)
{
    rsvp_u32_t tmpWrite;
    rsvp_u32_t tmpRead;

    #if defined(RSVP_TEST)
     assert(RingBuf_s != NULL);
    #endif

    /* Copy the Read/Write buffer indexs */
    tmpWrite = RingBuf_s->Buf_WriteIndex;
    tmpRead = RingBuf_s->Buf_ReadIndex;

    /* Return the number of bytes contained in the ring buffer */
    return((tmpWrite >=tmpRead) ? (tmpWrite -tmpRead) : (RingBuf_s->Buf_Size - (tmpRead -tmpWrite)));
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         RingBufFree(rsvp_RingBuf_t *RingBuf_s)
  * @brief      bytes free in the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     rsvp_u32_t
  * @detail
 */
rsvp_u32_t
rsvp_RingBufFree(rsvp_RingBuf_t *RingBuf_s)
{
    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
    #endif

    /* Return the number of bytes free in the ring buffer */
    return((RingBuf_s->Buf_Size - 1) - rsvp_RingBufUsed(RingBuf_s));
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufSize(rsvp_RingBuf_t *RingBuf_s)
  * @brief      bytes total in the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     rsvp_u32_t
  * @detail
 */
rsvp_u32_t
rsvp_RingBufSize(rsvp_RingBuf_t *RingBuf_s)
{
    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
    #endif

    /* Return the total number of bytes available in the ring buffer */
    return(RingBuf_s->Buf_Size);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufReadOne(rsvp_RingBuf_t *RingBuf_s)
  * @brief      read next byte from the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     rsvp_u8_t
  * @detail
 */
rsvp_u8_t
rsvp_RingBufReadOne(rsvp_RingBuf_t *RingBuf_s)
{
    unsigned char tmp;

    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
      assert(rsvp_RingBufUsed(RingBuf_s) != 0);
    #endif

    /* read the data byte */
    tmp = RingBuf_s->Buf[RingBuf_s->Buf_ReadIndex];

    /* increment the read index */
    rsvp_ringbuf_UpdateIndex(&RingBuf_s->Buf_ReadIndex, 1, RingBuf_s->Buf_Size);

    /* Return the character read */
    return(tmp);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufRead(rsvp_RingBuf_t *RingBuf_s, unsigned char *pucData, rsvp_u32_t ulLength)
  * @brief      read from the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     none
  * @detail
 */
void
rsvp_RingBufRead(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size)
{
    rsvp_u32_t tmp;

    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
      assert(Buf != NULL);
      assert(Buf_Size != 0);
      assert(Buf_Size <= rsvp_RingBufUsed(RingBuf_s));
    #endif

    /* Read the data from the ring buffer */
    for(tmp = 0; tmp < Buf_Size; tmp++) {
        Buf[tmp] = rsvp_RingBufReadOne(RingBuf_s);
    }
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufRead(rsvp_RingBuf_t *RingBuf_s, unsigned char *pucData, rsvp_u32_t ulLength)
  * @brief      read from the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     none
  * @detail
 */
void
rsvp_RingBufWriteOne(rsvp_RingBuf_t *RingBuf_s, rsvp_u8_t Buf)
{
    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
      assert(rsvp_RingBufFree(RingBuf_s) != 0);
    #endif
    
    /* Write the data byte into the ring buffer */
    RingBuf_s->Buf[RingBuf_s->Buf_WriteIndex] = Buf;

    /* update the write index */
    rsvp_ringbuf_UpdateIndex(&RingBuf_s->Buf_WriteIndex, 1, RingBuf_s->Buf_Size);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_RingBufRead(rsvp_RingBuf_t *RingBuf_s, unsigned char *pucData, rsvp_u32_t ulLength)
  * @brief      write to the ring buffer structure
  * @param      Ring Buffer Structure
  * @retval     none
  * @detail
 */
void
rsvp_RingBufWrite(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size) 
{
    rsvp_u32_t tmp;

    #if defined(RSVP_TEST)
      assert(RingBuf_s != NULL);
      assert(Buf != NULL);
      assert(Buf_Size != 0);
      assert(Buf_Size <= rsvp_RingBufFree(RingBuf_s));
    #endif
    
    //
    // Write the data into the ring buffer.
    //
    for(tmp = 0; tmp < Buf_Size; tmp++)
    {
        rsvp_RingBufWriteOne(RingBuf_s, Buf[tmp]);
    }
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
