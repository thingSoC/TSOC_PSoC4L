/**
  ******************************************************************************
  *
  * @file        rsvp_conf.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define the RSVPSIS configuration.
  *
  ******************************************************************************
  *
  * The RSVP-SIS configuration is controlled by defines in this file,
  * as well as the configuration of the TopDesign.cysch file in PSoC Creator.
  *
  * In order to disable the code for function, declare the function page as disabled : 
  * #define RSVP_IO_PG__DISABLED               TRUE
  * Would dissble the RSVP High Level IO Subsystem.
  *
  * #define UART_3_PG__DISABLED               TRUE
  * Would disable the functions supporting UART #3 (to save flash memory space)
  *
  * Note : If the page is disabled here, it doesn't need to exist in TopDesign.cysch
  *        Similarly, if you "Disable" an existing page in TopDesign.cysch, 
  *        you don't need to disable it here as well 
  *        (either disable it here or in TopDesign.cysch...)
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_CONF_H_
#define RSVP_CONF_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <CyLib.h>
#include <cydevice_trm.h>

/** @addtogroup rsvp_conf rsvp_conf
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Types
  * @{
  */

/**
  * Close the Doxygen rsvp_conf__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Constants
  * @{
  */
/*-----------------------------------------------------------------------------*/
/* Platform CPU Constants */
/** @TODO can we init theses automatically, from creator variables?            */
/*-----------------------------------------------------------------------------*/
#define RSVP_CPU_FREQ			        ( 48000000u )
#define RSVP_CPU_TYPE                   "arm cortex-m0"

/*-----------------------------------------------------------------------------*/
/* Basic RSVP Definitions                                                      */
/*-----------------------------------------------------------------------------*/
#define RSVP_DELAY_1S                   ( 1000 )
#define RSVP_HIGH_IMPEDANCE             ( 0x00000000 )

/*-----------------------------------------------------------------------------*/
/* enable/disable RSVPSIS platform system code                                 */
/*                                                                             */
//#define RSVPSIS_PG__DISABLED               TRUE
#if !defined(RSVP_USE_RSVPSIS) || defined(__DOXYGEN__)
	#if !defined(RSVPSIS_PG__DISABLED)
		#define RSVP_USE_RSVPSIS            TRUE		
		#define RSVP_VERSION                "1.3.0"
        #define RSVP_NAME                   "RSVPSIS Platform"
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_io code                                                 */
/*                                                                             */
//#define RSVP_IO_PG__DISABLED               TRUE
#if !defined(RSVP_USE_IO) || defined(__DOXYGEN__)
	#if !defined(RSVP_IO_PG__DISABLED)
		#define RSVP_USE_IO                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable rsvp_cli code                                                */
/*                                                                             */
/* Define Channel Numbers used by the CLI                                      */
#define RSVP_CLI_USBFS   0
#define RSVP_CLI_UART1   1
#define RSVP_CLI_UART2   2
#define RSVP_CLI_UART3   3
#define RSVP_CLI_UART4   4
#define RSVP_CLI_LEDS  255

#if !defined(RSVP_USE_CLI) || defined(__DOXYGEN__)
	#if !defined(RSVP_CLI_PG__DISABLED)
		#define RSVP_USE_CLI                TRUE
		#define RSVP_CLI_CHANNEL            RSVP_CLI_USBFS
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable bootloadable resources                                             */
/*                                                                             */
//#define BOOTLD_PG__DISABLED               TRUE
#if !defined(RSVP_USE_BOOTLD) || defined(__DOXYGEN__)
	#if !defined(BOOTLD_PG__DISABLED)
		#define RSVP_USE_BOOTLD             TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/*  emulated EEPROM / IPMI FRU flash memory block                              */
/*                                                                             */
//#define EEPROM_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_EEPROM_1) || defined(__DOXYGEN__)
	#if !defined(EEPROM_1_PG__DISABLED)
		#define RSVP_USE_EEPROM_1           TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable LVDT_1 resources                                             */
/*                                                                             */
//#define LVDT_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_LVDT_1) || defined(__DOXYGEN__)
	#if !defined(LVDT_1_PG__DISABLED)
		#define RSVP_USE_LVDT_1             TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable WDT_1 resources                                              */
/*                                                                             */
//#define WDT_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_WDT_1) || defined(__DOXYGEN__)
	#if !defined(WDT_1_PG__DISABLED)
		#define RSVP_USE_WDT_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable SysTick resources                                             */
/*                                                                             */
//#define SYSTICK_PG__DISABLED               TRUE
#if !defined(RSVP_USE_SYSTICK) || defined(__DOXYGEN__)
	#if !defined(SYSTICK_PG__DISABLED)
		#define RSVP_USE_SYSTICK                TRUE		
		#define RSVP_SYSTICK_TYPE               "arm cortex-m0"		
        #define RSVP_SYSTICK_FREQ			    ( 1000u )
        #define RSVP_SYSTICK_NVIC			    ( 15 )
        #define RSVP_SYSTICK_CONFIG			    ( RSVP_CPU_FREQ / RSVP_SYSTICK_FREQ )
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_1 resources                                            */
/*                                                                             */
//#define TIMER_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_1) || defined(__DOXYGEN__)
	#if !defined(TIMER_1_PG__DISABLED)
		#define RSVP_USE_TIMER_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_2 resources                                            */
/*                                                                             */
//#define TIMER_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_2) || defined(__DOXYGEN__)
	#if !defined(TIMER_2_PG__DISABLED)
		#define RSVP_USE_TIMER_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_3 resources                                            */
/*                                                                             */
//#define TIMER_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_3) || defined(__DOXYGEN__)
	#if !defined(TIMER_3_PG__DISABLED)
		#define RSVP_USE_TIMER_3                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_4 resources                                            */
/*                                                                             */
//#define TIMER_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_4) || defined(__DOXYGEN__)
	#if !defined(TIMER_4_PG__DISABLED)
		#define RSVP_USE_TIMER_4                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_5 resources                                            */
/*                                                                             */
#define TIMER_5_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_5) || defined(__DOXYGEN__)
	#if !defined(TIMER_5_PG__DISABLED)
		#define RSVP_USE_TIMER_5                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_6 resources                                            */
/*                                                                             */
#define TIMER_6_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_6) || defined(__DOXYGEN__)
	#if !defined(TIMER_6_PG__DISABLED)
		#define RSVP_USE_TIMER_6                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_7 resources                                            */
/*                                                                             */
#define TIMER_7_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_7) || defined(__DOXYGEN__)
	#if !defined(TIMER_7_PG__DISABLED)
		#define RSVP_USE_TIMER_7                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable TIMER_8 resources                                            */
/*                                                                             */
#define TIMER_8_PG__DISABLED               TRUE
#if !defined(RSVP_USE_TIMER_8) || defined(__DOXYGEN__)
	#if !defined(TIMER_8_PG__DISABLED)
		#define RSVP_USE_TIMER_8                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable USBFS resources                                              */
/*                                                                             */
#if !defined(RSVP_USE_USBFS) || defined(__DOXYGEN__)
	#if !defined(USBFS_PG__DISABLED)
		#define RSVP_USE_USBFS                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable I2C_1 resources                                              */
/*                                                                             */
//#define I2C_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_I2C_1) || defined(__DOXYGEN__)
	#if !defined(I2C_1_PG__DISABLED)
		#define RSVP_USE_I2C_1                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable I2C_2 resources                                              */
/*                                                                             */
//#define I2C_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_I2C_2) || defined(__DOXYGEN__)
	#if !defined(I2C_2_PG__DISABLED)
		#define RSVP_USE_I2C_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_1 resources                                             */
/*                                                                             */
//#define UART_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_UART_1) || defined(__DOXYGEN__)
	#if !defined(UART_1_PG__DISABLED)
		#define RSVP_USE_UART_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_2 resources                                             */
/*                                                                             */
//#define UART_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_UART_2) || defined(__DOXYGEN__)
	#if !defined(UART_2_PG__DISABLED)
		#define RSVP_USE_UART_2                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_3 resources                                             */
/*                                                                             */
#define UART_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_UART_3) || defined(__DOXYGEN__)
	#if !defined(UART_3_PG__DISABLED)
		#define RSVP_USE_UART_3                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable UART_4 resources                                             */
/*                                                                             */
#define UART_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_UART_4) || defined(__DOXYGEN__)
	#if !defined(UART_4_PG__DISABLED)
		#define RSVP_USE_UART_3                TRUE		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_1 resources                                            */
/*                                                                             */
#define OPAMP_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_OPAMP_1) || defined(__DOXYGEN__)
	#if !defined(OPAMP_1_PG__DISABLED)
		#define RSVP_USE_OPAMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_2 resources                                            */
/*                                                                             */
#define OPAMP_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_OPAMP_2) || defined(__DOXYGEN__)
	#if !defined(OPAMP_2_PG__DISABLED)
		#define RSVP_USE_OPAMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_3 resources                                            */
/*                                                                             */
#define OPAMP_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_OPAMP_3) || defined(__DOXYGEN__)
	#if !defined(OPAMP_3_PG__DISABLED)
		#define RSVP_USE_OPAMP_3                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable OPAMP_4 resources                                            */
/*                                                                             */
#define OPAMP_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_OPAMP_4) || defined(__DOXYGEN__)
	#if !defined(OPAMP_4_PG__DISABLED)
		#define RSVP_USE_OPAMP_4                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_1 resources                                              */
/*                                                                             */
#define CMP_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_CMP_1) || defined(__DOXYGEN__)
	#if !defined(CMP_1_PG__DISABLED)
		#define RSVP_USE_CMP_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_2 resources                                              */
/*                                                                             */
#define CMP_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_CMP_2) || defined(__DOXYGEN__)
	#if !defined(CMP_2_PG__DISABLED)
		#define RSVP_USE_CMP_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_3 resources                                              */
/*                                                                             */
#define CMP_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_CMP_3) || defined(__DOXYGEN__)
	#if !defined(CMP_3_PG__DISABLED)
		#define RSVP_USE_CMP_3                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable CMP_4 resources                                              */
/*                                                                             */
#define CMP_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_CMP_4) || defined(__DOXYGEN__)
	#if !defined(CMP_4_PG__DISABLED)
		#define RSVP_USE_CMP_4                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC_1 resources                                                */
/*                                                                             */
//#define ADC_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_ADC_1) || defined(__DOXYGEN__)
	#if !defined(ADC_1_PG__DISABLED)
		#define RSVP_USE_ADC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC_2 resources                                                */
/*                                                                             */
#define ADC_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_ADC_2) || defined(__DOXYGEN__)
	#if !defined(ADC_2_PG__DISABLED)
		#define RSVP_USE_ADC_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC_3 resources                                                */
/*                                                                             */
#define ADC_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_ADC_3) || defined(__DOXYGEN__)
	#if !defined(ADC_3_PG__DISABLED)
		#define RSVP_USE_ADC_3                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable ADC_4 resources                                                */
/*                                                                             */
#define ADC_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_ADC_4) || defined(__DOXYGEN__)
	#if !defined(ADC_4_PG__DISABLED)
		#define RSVP_USE_ADC_4                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_1 resources                                              */
/*                                                                             */
#define DAC_1_PG__DISABLED               TRUE
#if !defined(RSVP_USE_DAC_1) || defined(__DOXYGEN__)
	#if !defined(DAC_1_PG__DISABLED)
		#define RSVP_USE_DAC_1                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_2 resources                                              */
/*                                                                             */
#define DAC_2_PG__DISABLED               TRUE
#if !defined(RSVP_USE_DAC_2) || defined(__DOXYGEN__)
	#if !defined(DAC_2_PG__DISABLED)
		#define RSVP_USE_DAC_2                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_3 resources                                              */
/*                                                                             */
#define DAC_3_PG__DISABLED               TRUE
#if !defined(RSVP_USE_DAC_3) || defined(__DOXYGEN__)
	#if !defined(DAC_3_PG__DISABLED)
		#define RSVP_USE_DAC_3                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable DAC_4 resources                                              */
/*                                                                             */
#define DAC_4_PG__DISABLED               TRUE
#if !defined(RSVP_USE_DAC_4) || defined(__DOXYGEN__)
	#if !defined(DAC_4_PG__DISABLED)
		#define RSVP_USE_DAC_4                TRUE
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user LED resources                                           */
/*                                                                             */
//#define USER_LED_PG__DISABLED               TRUE
#if !defined(RSVP_USE_USER_LED) || defined(__DOXYGEN__)
	#if !defined(USER_LED_PG__DISABLED)
		#define RSVP_USE_USER_LED                TRUE		
		#define RSVP_USE_USER_LED_NUM               4		
	#endif
#endif

/*-----------------------------------------------------------------------------*/
/* enable/disable user switch (input pushbutton) resources */
/*                                                                             */
//#define USER_SW_PG__DISABLED               TRUE
#if !defined(RSVP_USE_USER_SW) || defined(__DOXYGEN__)
	#if !defined(USER_SW_PG__DISABLED)
		#define RSVP_USE_USER_SW                TRUE		
	#endif
#endif

/**
  * Close the Doxygen rsvp_conf_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Variables
  * @{
  */

/** Platform Globals */

/**
  * Close the Doxygen rsvp_conf_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_conf_Exported_Functions
  * @{
  */

/**
  * Close the Doxygen rsvp_conf_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_CONF_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_conf group.
  *    @}
*/
