/**
 ******************************************************************************
    @file        rsvp_platform.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the rsvp_platform hardware porting/mapping routines
    @section     rsvp_platform_intro rsvp_platform hardware porting/mapping
    @par
    The "rsvp_platform" encapsulates the hardware platform into a number of simple APIs. \n
    Each component in the platform, like UARTs, ADC's, etc. have their own simple HAL API. \n
    The "rsvp_platform" HAL API uses the component instance name as a prefix to it's functions, \n
	for example, "UART_1_Start();" or "UART_1_Stop();" \n 
    @par
    Using the PSoC Creator System, most of these API's are auto-generated. \n
	The RSVPSIS layer "wrapper" and high level "rsvp_platform" API's are contained in this file. \n
    @section    rsvp_platform_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_fru.h>
#include <rsvp_adc.h>
#include <rsvp_cli.h>
#include <rsvp_io.h>
#include "stdio.h"
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform rsvp_platform
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------*/
/* Platform Functions                                                          */
/*-----------------------------------------------------------------------------*/
/**
  * @fn         void rsvp_platform_Start(void)
  * @brief      called to initialize all of the rsvp_platform hardware systems
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Start(void)
{
    rsvp_RetCode_t RetCode = RSVP_SUCCESS;
    
	#if defined(RSVP_USE_EEPROM_1)
	  EEPROM_1_Start();
	#endif

	#if defined(RSVP_USE_LVDT_1)
	  LVDT_1_IRQ_Start();
      LVDT_1_IRQ_StartEx(LVDT_1_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_WDT_1)
       WDT_1_Start();
	   WDT_1_IRQ_Start();
       WDT_1_IRQ_StartEx(WDT_1_IRQ_Handler);
    #endif
	
	#if defined(RSVP_USE_SYSTICK)		
	  /* Start the SysTick Timer - included by default in ARM Cortex Arch. */
	  SysTick_StartEx(SysTick_IRQ_Handler);
    #endif
	
	#if defined(RSVP_USE_TIMER_1)
	  /* Start TIMER_1 */	
	  TIMER_1_Start();
      TIMER_1_IRQ_StartEx(TIMER_1_IRQ_Handler);
      /* Clear any pending Interrupts for TIMER_1 */
       TIMER_1_IRQ_ClearPending();
    #endif
	
	#if defined(RSVP_USE_TIMER_2)	
	  /* Start TIMER_2 */	
	  TIMER_2_Start();
      TIMER_2_IRQ_StartEx(TIMER_2_IRQ_Handler);
    #endif
	
	#if defined(RSVP_USE_TIMER_3)	
	  /* Start TIMER_3 */	
	  TIMER_3_Start();
      TIMER_3_IRQ_StartEx(TIMER_3_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_TIMER_4)		
	  /* Start TIMER_4 */	
	  TIMER_4_Start();
      TIMER_4_IRQ_StartEx(TIMER_4_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_TIMER_5)		
	  /* Start TIMER_5 */	
	  TIMER_5_Start();
      TIMER_5_IRQ_StartEx(TIMER_5_IRQ_Handler);
    #endif

    #if defined(RSVP_USE_TIMER_6)		
	  /* Start TIMER_6 */	
	  TIMER_6_Start();
      TIMER_6_IRQ_StartEx(TIMER_6_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_TIMER_7)		
	  /* Start TIMER_7 */	
	  TIMER_7_Start();
      TIMER_7_IRQ_StartEx(TIMER_7_IRQ_Handler);
    #endif

    #if defined(RSVP_USE_TIMER_8)		
	  /* Start TIMER_8 */	
	  TIMER_8_Start();
      TIMER_8_IRQ_StartEx(TIMER_8_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_I2C_1)	
	  /* Start the Primary I2C channel */
	  /* EZI2C gets mapped to IPMI FRU address space)  */
	  I2C_1_Start();
	  I2C_1_EzI2CSetBuffer1(rsvp_FRU_PDU_Size, rsvp_FRU_PDU_Size, (void *) rsvp_fru_bmc);
	  I2C_1_EzI2CSetBuffer2(rsvp_FRU_PDU_Size, rsvp_FRU_PDU_Size, (void *) rsvp_fru_bmc);
	  I2C_1_Start();
    #endif
	
	#if defined(RSVP_USE_UART_1)	
	  /* Start the Primary UART (usually connected to USB host for CLI) */
	  UART_1_Start();
        #if defined(CY_ISR_UART_1_RX_IRQ_H)
           UART_1_RX_IRQ_StartEx(UART_1_RX_IRQ_Handler);
        #endif
	#endif

	#if defined(RSVP_USE_UART_2)	
	  /* Start the Secondary UART Serial Line Component and enable Interrupt */	
	  UART_2_Start();
        #if defined(CY_ISR_UART_2_RX_IRQ_H)
           UART_2_RX_IRQ_StartEx(UART_2_RX_IRQ_Handler);
        #endif    
    #endif

	#if defined(RSVP_USE_OPAMP_1)	
	  /* Start the Component */
      OPAMP_1_Start();
    #endif

	#if defined(RSVP_USE_OPAMP_2)	
	  /* Start the Component */
      OPAMP_2_Start();
    #endif

	
	#if defined(RSVP_USE_CMP_1)	
	  /* Start the Component and enable Interrupts */
      CMP_1_Start();
      CMP_1_IRQ_StartEx(CMP_1_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_CMP_2)	
	  /* Start the Component and enable Interrupts */
      CMP_2_Start();
      CMP_2_IRQ_StartEx(CMP_2_IRQ_Handler);
    #endif

	#if defined(RSVP_USE_ADC_1)	
	  /* Start the Analog-to-Digital Converter(ADC) Component and enable Interrupt */
      ADC_1_Start();
      ADC_1_IRQ_StartEx(ADC_1_IRQ_Handler);
	
	  /* Start ADC conversion */
	  ADC_1_StartConvert();
    #endif

	#if defined(RSVP_USE_DAC_1)	
	  /* Start the Component and initialize */
      IDAC_1_Start();
	  IDAC_1_SetValue(0u);
    #endif

	#if defined(RSVP_USE_DAC_2)	
	  /* Start the Component and initialize */
      IDAC_2_Start();
	  IDAC_2_SetValue(0u);
    #endif
	
	#if defined(RSVP_USE_USER_SW)
	  //USER_SW_1_ClearInterrupt();   
      USER_SW_1_IRQ_StartEx(USER_SW_1_IRQ_Handler);
	  USER_SW_1_IRQ_Enable();
	  user_sw_1_irq_flag = 0;
    #endif

	#if defined(RSVP_USE_USER_LED)	
	  /* initialise LEDs to off */
      USER_LED_1_Write(RSVP_LED_ON);
	  USER_LED_2_Write(RSVP_LED_OFF);
	  USER_LED_3_Write(RSVP_LED_OFF);
    #endif

	#if defined(RSVP_USE_IO)	
	  rsvp_io_Start();
    #endif
    
	/* Enable global interrupts */
    CyGlobalIntEnable;

    /* USBFS Initialize */
    #if defined(RSVP_USE_USBFS)
      /* Start USBFS operation with 5-V operation. */
      USBFS_Start(0, USBFS_5V_OPERATION);
      /* N.B. Deadlock with no USB plugged in - put in a timeout break... */
      // RetCode = RSVP_NO_RESOURCE ;
      while (0u == USBFS_GetConfiguration());
      USBFS_CDC_Init();
    #endif
    
	return(RetCode);
}

/**
  * @fn         void rsvp_platform_Run(void)
  * @brief      called to run the hardware rsvp_platform state machines
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t rsvp_platform_Run(void) {
   rsvp_RetCode_t RetCode = RSVP_SUCCESS;

   /* run the RSVP state machines... */
   #if defined(RSVP_USE_ADC_1)
	    rsvp_ADC_Poll();
   #endif

   #if defined(RSVP_USE_CLI)
	   rsvp_CLI_Poll();
   #endif

   #if defined(RSVP_USE_USBFS)
        //rsvp_USBFS_Poll();
   #endif
    
   return(RetCode);
}

/**
  * @fn         void rsvp_platform_Stop(void)
  * @brief      called to stop all of the hardware rsvp_platform systems
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Stop(void)
{	
	/* Disable global interrupts */
    CyGlobalIntDisable;	
	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Sleep(void)
  * @brief      called to put the hardware rsvp_platform system to sleep
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Sleep(void)
{
	/* Call all component stop/sleep functions here . 
	 * This project doesn't have any components that needs shut down */ 
	 
	/* Set all the port pin registers to high impedence mode */
	CY_SET_REG32(CYREG_PRT0_PC , RSVP_HIGH_IMPEDANCE);
	CY_SET_REG32(CYREG_PRT1_PC , RSVP_HIGH_IMPEDANCE);
	CY_SET_REG32(CYREG_PRT2_PC , RSVP_HIGH_IMPEDANCE);
	CY_SET_REG32(CYREG_PRT3_PC , RSVP_HIGH_IMPEDANCE);
	CY_SET_REG32(CYREG_PRT4_PC , RSVP_HIGH_IMPEDANCE);
	
	/* Set the WakeUp Switch pin in resistive pull up mode for detecting 
	 * the falling edge interrupt when switch is pressed */
	//USER_SW_SetDriveMode(USER_SW_DM_RES_UP);
	
	return(RSVP_SUCCESS);
}

/**
  * @fn         void rsvp_platform_Wake(void)
  * @brief      called to wake the hardware rsvp_platform system
  * @param      None.
  * @retval     rsvp_RetCode_t
  */
rsvp_RetCode_t
rsvp_platform_Wake(void)
{
	/* Call all component restore functions here . 
	 * This project doesn't have any components that needs to be restored */ 
	 
	/* Restore all the pin states */
	
	/* Set the output pins in strong drive mode */
	//USER_LEDR_SetDriveMode(USER_SW_DM_STRONG);
	
	return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of rsvp_platform.c */

