/**
 ******************************************************************************
    @file        rsvp_io.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the rsvp_io Input/Output Streams.
    @section     rsvp_io_intro rsvp_io hardware routines
    @par	
    @section    rsvp_Fio_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_io.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

#include <stddef.h>
#include <sys/types.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include "rsvp_ringbuf.h"

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io rsvp_io
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global variables                                                            */
/*-----------------------------------------------------------------------------*/
unsigned char RingBuffer[64], usbBuffer[64];
rsvp_RingBuf_t RingBuf_s;

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_io_Start(void)
  * @brief      Starts the RSVP_IO system.
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_RetCode_t rsvp_io_Start(void) {
    rsvp_RingBufInit(&RingBuf_s, RingBuffer, sizeof(RingBuffer));
    rsvp_RingBufFlush(&RingBuf_s);
    return(RSVP_SUCCESS);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_io_GetRxBufferSize(rsvp_u8_t channel)
  * @brief      Returns the number of received bytes available in the RX buffer.
  * @param      None.
  * @retval     rsvp_u32_t
  * @detail
  */
rsvp_u32_t rsvp_io_GetRxBufferSize(rsvp_u8_t channel)
{
  rsvp_u8_t BufSize = 0;
	
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == RSVP_CLI_USBFS) {
            #if defined(RSVP_USE_USBFS)
              BufSize = USBFS_GetCount();
            #endif
        } else if (channel == 1) {
          #if defined(RSVP_USE_UART_1)
	        #if defined CY_SCB_UART_1_H
		      BufSize = UART_1_SpiUartGetRxBufferSize();
		    #else 
		      BufSize = UART_1_GetRxBufferSize();
		    #endif
          #endif
        } else if (channel == 2) {
          #if defined(RSVP_USE_UART_2)
	        #if defined CY_SCB_UART_2_H
		      BufSize = UART_2_SpiUartGetRxBufferSize();
		    #else 
		      BufSize = UART_2_GetRxBufferSize();
		    #endif
          #endif
        }
      #endif	
	return(BufSize);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
  * @brief      put a character
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_RetCode_t 
rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
{
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == RSVP_CLI_USBFS) {
            #if defined(RSVP_USE_USBFS)
              while (USBFS_CDCIsReady() == 0);
              if (USBFS_CDCIsReady()) {
                USBFS_PutChar(Buffer);
              }
              #endif
        } else if (channel == 1) {
          #if defined(RSVP_USE_UART_1)
	        #if defined CY_SCB_UART_1_H
		      UART_1_UartPutChar(Buffer);
		    #else 
		      UART_1_PutChar(Buffer);
		    #endif
          #endif
        } else if (channel == 2) {
          #if defined(RSVP_USE_UART_2)
	        #if defined CY_SCB_UART_2_H
		      UART_2_UartPutChar(Buffer);
		    #else 
		      UART_2_PutChar(Buffer);
		    #endif
          #endif
        }
      #endif	
	return(RSVP_SUCCESS);	
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer)
  * @brief      put a character
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_u8_t
rsvp_io_GetChar(rsvp_u8_t channel)
{
  rsvp_u8_t Buffer = 0;
  rsvp_u32_t USBFS_dataCount;	
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == RSVP_CLI_USBFS) {
            #if defined(RSVP_USE_USBFS)
              /* check for new data on USBFS interface first */
              if ((USBFS_dataCount = USBFS_GetCount()) != 0) {
                 /* get the new USB data, might be more data now... */
                 if (USBFS_DataIsReady()) {
                    /* get the new USB data */
                    USBFS_dataCount = USBFS_GetAll(usbBuffer);
                    /* add the new data to the ring buffer */
                    rsvp_RingBufWrite(&RingBuf_s, usbBuffer, USBFS_dataCount);
                }
              }
              /* always return data from the ring buffer... */
              if (rsvp_isRingBufEmpty(&RingBuf_s) == FALSE) {
                  Buffer = rsvp_RingBufReadOne(&RingBuf_s);
              } else {
                 /* no data avalilable, return a zero... */
                 Buffer = 0;
              }
            #endif            
        } else if (channel == 1) {
          #if defined(RSVP_USE_UART_1)            
	        #if defined CY_SCB_UART_1_H
		      Buffer = UART_1_UartGetChar();
		    #else 
		      Buffer = UART_1_GetChar();
		    #endif
          #endif
        } else if (channel == 2) {
          #if defined(RSVP_USE_UART_2)
	        #if defined CY_SCB_UART_2_H
		      Buffer = UART_2_UartGetChar();
		    #else 
		      Buffer = UART_2_GetChar();
		    #endif
          #endif
        }		
      #endif	
	return(Buffer);
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_PutString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
  * @brief      get a string, blocking...
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
  */
rsvp_RetCode_t 
rsvp_io_PutString(rsvp_u8_t channel, char *Buffer)
{
	  #if (RSVP_USE_IO == TRUE)
	    if (channel == RSVP_CLI_USBFS) {
            #if defined(RSVP_USE_USBFS)
              while (USBFS_CDCIsReady() == 0);
              if (USBFS_CDCIsReady()) {
                USBFS_PutString(Buffer);
              }
            #endif            
        } else if (channel == 1) {
          #if defined(RSVP_USE_UART_1)
	        #if defined CY_SCB_UART_1_H
		      UART_1_UartPutString(Buffer);
		    #else 
		      UART_1_PutString(Buffer);
		    #endif
          #endif
        } else if (channel == 2) {
          #if defined(RSVP_USE_UART_2)
            #if defined CY_SCB_UART_2_H
		      UART_2_UartPutString(Buffer);
		    #else 
		      UART_2_PutString(Buffer);
		    #endif
          #endif
        } else if (channel == 255) {
          #if defined(RSVP_USE_USER_LED)
          #endif
        }
      #endif	
	return(RSVP_SUCCESS);	
}

/*-----------------------------------------------------------------------------*/
/**
  * @fn         rsvp_u8_t rsvp_io_GetString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
  * @brief      get a string
  * @param      None.
  * @retval     rsvp_RetCode_t
  * @detail
      Channel is the physical channel number (UART_1, _2, _3, etc.) UART_1 for now. 
      Buffer is a pointer to a character buffer for the incoming string from the UART.
      BufLen is the maximum length of the buffer in characters (bytes),
      (which include the trailing null (0) to terminate the string.
     
      This function will receive characters from the UART_1 input and store them
      in the buffer pointed to by Buffer, until a termination character
      is received.  The valid termination characters are CR, LF, or ESC.  
      A CRLF (\r\n) pair is treated as a single termination character.  
      The termination characters are not stored in the string but are
      converted to a string terminator (NULL=0), and the function will return.
     
      This function is blocking, and will not return until a 
      line termination charcter has been received and processed.
     
      Returns the count of valid characters that were stored, 
      which does not include the trailing string terminator (NULL=0).
     
      Limits : String Length is limited to BufLen
  */
rsvp_u8_t rsvp_io_GetString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen)
{
    rsvp_u8_t CharCnt = 0;
    char CurChar;
    static char LineTermFound = 0;

	/* make sure to leave space for the trailing null terminator */
    BufLen--;

    /* Blocking - this routine will block until a line termination character is received */
    while(1)
    {
        /* Blocking - GetChar will block until a charcter is received */ 
        CurChar = rsvp_io_GetChar(channel);
        /* error on character received, discard it and try again */
        if (CurChar == 0) {
            continue;
        }

        /* backspace processing */
        /* TODO : add "delete" processing */
        if(CurChar == '\b')
        {
            /* only if there are characters still in the buffer */
            if(CharCnt)
            {
                /* delete (using backspace) the previous character */
                rsvp_io_PutString(channel, "\b \b");

                /* then decrement the number of characters (left) in the buffer */
                CharCnt--;
            }

            /* backspace processed, now continue back to read the next character */
            continue;
        }

        /* If the current character is LF and last character was CR, then just   */
        /* ignore the LF (drop it), it may also have been from the previous line */
        if((CurChar == '\n') && LineTermFound)
        {
            LineTermFound = 0;
            continue;
        }

        /* check for a line termination character */
        if((CurChar == '\r') || (CurChar == '\n') || (CurChar == 0x1b))
        {
            /* remember that we got a Carriage Return, usually followed by a line feed */
            if(CurChar == '\r')
            {
                LineTermFound = 1;
            }
            break;
        }

        /* Process the received string, and stuff it into the Buffer */
        /* If we have reached the end of the Buffer we are out of buffer memory */
        /* only thing we can do is drop the additional characters until a newline is received */
        /* TODO: Flag a buffer overrun error if we have dropped any characters */
        if(CharCnt < BufLen)
        {
            Buffer[CharCnt] = CurChar;
            CharCnt++;

            /* Echo the character back to the user */
            if (CurChar != 0) {
                rsvp_io_PutChar(channel, CurChar);
            }
        }
    }

    /* null terminate the string */
    Buffer[CharCnt] = 0;

    /* Echo a CRLF pair to the terminal to end the line */
    rsvp_io_PutString(channel, "\r\n");

    /* Return the total count of characters in the buffer */
    return(CharCnt);
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of rsvp_io.c */

