/**
  ******************************************************************************
  *
  * @file        rsvp_adc.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define all the Analog-to-Digital Converter routines
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_ADC_H_
#define RSVP_ADC_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <CyLib.h>
#include <cydevice_trm.h>

/** @addtogroup rsvp_platform rsvp_platform
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc_Exported_Types
  * @{
  */

/**
  * Close the Doxygen rsvp_adc__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc_Exported_Constants
  * @{
  */

/**
  * Close the Doxygen rsvp_adc_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_adc_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc_Exported_Variables
  * @{
  */

/** Platform Globals */

/**
  * Close the Doxygen rsvp_adc_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_adc_Exported_Functions
  * @{
  */
extern rsvp_RetCode_t rsvp_ADC_Poll(void);

/**
  * Close the Doxygen rsvp_adc_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_ADC_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_platform group.
  *    @}
*/

