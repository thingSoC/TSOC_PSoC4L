/**
 ******************************************************************************
    @file        rsvp_interrupts.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
  * @brief       Defines all the interrupt service routines (ISR's) and low level routines.
    @section     rsvp_interrupts_intro rsvp_interrupts Platform Interrupts 
    @par
    The rsvp_interrupts module contains all the low level hardware and interrupt service routines.
    We thought about naming it "rsvp_cpuSoC", because it really contains all the low level mapping 
	to the actual hardware CPU and System-on-Chip platform.
    @par	
    @section    rsvp_interrupts_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_cli.h>
#include <rsvp_adc.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_interrupts rsvp_interrupts
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Global Variables   (Interrupt Context)                                      */
/*-----------------------------------------------------------------------------*/
/* The variables (flags and counters) below are used by the interrupt routines */
/* You may want to use "Critical_Section" guards around them when depending on */
/* these variables to be stable across several operations, or make a copy...   */
/* as they may change at any time within the hardware interrupt context.       */
/*-----------------------------------------------------------------------------*/
rsvp_u8_t   cpu_irq_status                       = 0u;
rsvp_u8_t   cpu_irq_flag                         = 0u;

/*-----------------------------------------------------------------------------*/
/* Interrupt Handlers                                                          */
/*-----------------------------------------------------------------------------*/
#if defined(RSVP_USE_LVDT_1)
CY_ISR_PROTO(LVDT_1_IRQ_Handler);
rsvp_u32_t  lvdt_1_irq_status = 0u;
rsvp_u8_t   lvdt_1_irq_flag   = 0u;
/**
  * @fn         void LVDT_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the LVDT_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(LVDT_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    lvdt_1_irq_status = 0u;
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    lvdt_1_irq_flag++; 
	/* Clear handled interrupt */
	//LVDT_1_ClearInterrupt(wdt_1_irq_status);
}
#endif

#if defined(RSVP_USE_WDT_1)
CY_ISR_PROTO(WDT_1_IRQ_Handler);
rsvp_u32_t  wdt_1_irq_status = 0u;
rsvp_u8_t   wdt_1_irq_flag   = 0u;
/**
  * @fn         void WDT_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the WDT_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(WDT_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    wdt_1_irq_status = 0u;
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    wdt_1_irq_flag++; 
	/* Clear handled interrupt */
	//WDT_1_ClearInterrupt(wdt_1_irq_status);
}
#endif

#if defined(RSVP_USE_SYSTICK)
CY_ISR_PROTO(SysTick_IRQ_Handler);
rsvp_u32_t  systick_irq_status                   = 0u;
rsvp_u32_t  systick_irq_flag                     = 0u;
rsvp_u32_t  systick_blink_flag                   = 0u;

CY_ISR(SysTick_IRQ_Handler)
{
    /* We got a "Tick" Interrupt, so set the RSVP_SysTickFlag to 1  */
    systick_irq_flag++;
    systick_blink_flag++;
	
	if (systick_blink_flag > 1000) {
        /* N.B. change this to use rsvp_io_putString! not direct hardware write! */
		USER_LED_1_Write(!USER_LED_1_Read());
		systick_blink_flag = 0;
	}
}

/*
 * Setup the systick timer to generate the Tick interrupt at a frequency of 1mSec
 */
void SysTick_StartEx(cyisraddress address)
{
	/* Configure SysTick to interrupt at 1 millsecond rate. (For 48Mhz CPU Clock) */
    //SysTick_Config( 48000 );
    SysTick_Config( RSVP_SYSTICK_CONFIG );
    
    /* Register the new SysTick Interrupt Vector Handler */
    CyIntSetSysVector(RSVP_SYSTICK_NVIC, ( cyisraddress ) address);
    
    /* Enable Systick Interrupt in NVIC */
    CyIntEnable(RSVP_SYSTICK_NVIC);
}
#endif

#if defined(RSVP_USE_TIMER_1)
CY_ISR_PROTO(TIMER_1_IRQ_Handler);
rsvp_u32_t  timer_1_irq_status                   = 0u;
rsvp_u8_t   timer_1_irq_flag                     = 0u;
/**
  * @fn         void TIMER_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_1_irq_status = TIMER_1_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_1_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_1_ClearInterrupt(timer_1_irq_status);
    /* TIMER_1 is typically used as Reset Timer for entering the Bootloader program. */
}
#endif

#if defined(RSVP_USE_TIMER_2)	
CY_ISR_PROTO(TIMER_2_IRQ_Handler);
rsvp_u32_t  timer_2_irq_status                   = 0u;
rsvp_u8_t   timer_2_irq_flag                     = 0u;
/**
  * @fn         void TIMER_2_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_2_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_2_irq_status = TIMER_2_GetInterruptSource();
	/* increment the timer expired flag, which is the  */
	/* number of times the Modbus 3.5 Character Timeout has occurred */
    timer_2_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_2_ClearInterrupt(timer_2_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_3)
CY_ISR_PROTO(TIMER_3_IRQ_Handler);
rsvp_u32_t  timer_3_irq_status                   = 0u;
rsvp_u8_t   timer_3_irq_flag                     = 0u;
/**
  * @fn         void TIMER_3_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_3 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_3_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_3_irq_status = TIMER_3_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_3_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_3_ClearInterrupt(timer_3_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_4)
CY_ISR_PROTO(TIMER_4_IRQ_Handler);
rsvp_u32_t  timer_4_irq_status                   = 0u;
rsvp_u8_t   timer_4_irq_flag                     = 0u;

/**
  * @fn         void TIMER_4_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_4 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_4_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_4_irq_status = TIMER_4_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_4_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_4_ClearInterrupt(timer_4_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_5)
CY_ISR_PROTO(TIMER_5_IRQ_Handler);
rsvp_u32_t  timer_5_irq_status                   = 0u;
rsvp_u8_t   timer_5_irq_flag                     = 0u;

/**
  * @fn         void TIMER_5_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_5 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_5_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_5_irq_status = TIMER_5_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_5_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_5_ClearInterrupt(timer_5_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_6)
CY_ISR_PROTO(TIMER_6_IRQ_Handler);
rsvp_u32_t  timer_6_irq_status                   = 0u;
rsvp_u8_t   timer_6_irq_flag                     = 0u;

/**
  * @fn         void TIMER_6_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_6 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_6_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_6_irq_status = TIMER_6_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_6_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_6_ClearInterrupt(timer_6_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_7)
CY_ISR_PROTO(TIMER_7_IRQ_Handler);
rsvp_u32_t  timer_7_irq_status                   = 0u;
rsvp_u8_t   timer_7_irq_flag                     = 0u;

/**
  * @fn         void TIMER_7_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_7 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_7_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_7_irq_status = TIMER_7_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_7_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_7_ClearInterrupt(timer_7_irq_status);
}
#endif

#if defined(RSVP_USE_TIMER_8)
CY_ISR_PROTO(TIMER_8_IRQ_Handler);
rsvp_u32_t  timer_8_irq_status                   = 0u;
rsvp_u8_t   timer_8_irq_flag                     = 0u;

/**
  * @fn         void TIMER_8_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the TIMER_8 Component
  * @param      void
  * @retval     void
  */
CY_ISR(TIMER_8_IRQ_Handler)
{
	/* Read interrupt source registers */
    timer_8_irq_status = TIMER_8_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    timer_8_irq_flag++; 
	/* Clear handled interrupt */
	TIMER_8_ClearInterrupt(timer_8_irq_status);
}
#endif


#if defined(RSVP_USE_UART_1)
rsvp_u32_t  uart_1_rx_irq_status                 = 0u;
rsvp_u8_t   uart_1_rx_irq_flag                   = 0u;
rsvp_u32_t  uart_1_tx_irq_status                 = 0u;
rsvp_u8_t   uart_1_tx_irq_flag                   = 0u;

#if defined(CY_ISR_UART_1_RX_IRQ_H)
  CY_ISR_PROTO(UART_1_RX_IRQ_Handler);
  /**
    * @fn         void UART_1_RX_IRQ_Handler(void)
    * @brief      Interrupt Service Routine for the UART_1 Component
    * @param      void
    * @retval     void
  */
  CY_ISR(UART_1_RX_IRQ_Handler)
  {
	/* Read RX interrupt status registers */
    uart_1_rx_irq_status = UART_1_GetRxInterruptSourceMasked();
    /* increment the data ready flag, indicates number of characters received */
	uart_1_rx_irq_flag++;
	/* Clear handled interrupt */	/* this component is self-clearing */
    UART_1_ClearRxInterruptSource(uart_1_rx_irq_status);
  }
  #endif 
#endif

#if defined(RSVP_USE_UART_2)
rsvp_u8_t   uart_2_rx_irq_status                 = 0u;
rsvp_u8_t   uart_2_rx_irq_flag                   = 0u;
rsvp_u8_t   uart_2_tx_irq_status                 = 0u;
rsvp_u8_t   uart_2_tx_irq_flag                   = 0u;
#endif

#if defined(CY_ISR_UART_2_RX_IRQ_H)
CY_ISR_PROTO(UART_2_RX_IRQ_Handler);
/**
  * @fn         void UART_2_RX_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the UART_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(UART_2_RX_IRQ_Handler)
{
	/* Read RX interrupt status registers */
    //uart_2_rx_irq_status = UART_2_ReadRxStatus();
    /* increment the data ready flag, indicates number of characters received */
	//uart_2_rx_irq_flag++;
	/* insure that the line stays in receive mode until timeout */
	// UART_2_txen_Write(0x00);
	/* Clear handled interrupt */
	/* this component is self-clearing */
    //UART_2_ClearRxInterruptSource(uart_2_rx_irq_status);
}
#endif

#if defined(RSVP_USE_CMP_1)
CY_ISR_PROTO(CMP_1_IRQ_Handler);
rsvp_u32_t  cmp_1_irq_status                   = 0u;
rsvp_u8_t   cmp_1_irq_flag                     = 0u;

/**
  * @fn         void CMP_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the CMP_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(CMP_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    cmp_1_irq_status = CMP_1_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    cmp_1_irq_flag++; 
	/* Clear handled interrupt */
	CMP_1_ClearInterrupt(cmp_1_irq_status);
}
#endif

#if defined(RSVP_USE_CMP_2)
CY_ISR_PROTO(CMP_2_IRQ_Handler);
rsvp_u32_t  cmp_2_irq_status                   = 0u;
rsvp_u8_t   cmp_2_irq_flag                     = 0u;

/**
  * @fn         void CMP_2_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the CMP_2 Component
  * @param      void
  * @retval     void
  */
CY_ISR(CMP_2_IRQ_Handler)
{
	/* Read interrupt source registers */
    //cmp_2_irq_status = CMP_2_GetInterruptSource();
	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
    cmp_2_irq_flag++; 
	/* Clear handled interrupt */
	//CMP_2_ClearInterrupt(cmp_2_irq_status);
}
#endif

/*-----------------------------------------------------------------------------*/
/* ADC_1                                                                       */
/*-----------------------------------------------------------------------------*/
/* If the ADC is defined, then include it's interrupt handler */
#if defined(RSVP_USE_ADC_1)	
CY_ISR_PROTO(ADC_1_IRQ_Handler);
rsvp_u32_t  adc_1_irq_status                     = 0u;
rsvp_u8_t   adc_1_irq_flag                       = 0u;
rsvp_u8_t   adc_1_range_flag                     = 0u;
rsvp_s32_t  adc_1_gain                           = 0u;
rsvp_s16_t  adc_1_data[32];
/**
  * @fn         void ADC_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the ADC Subsystem
  * @param      void
  * @retval     void
  */
CY_ISR(ADC_1_IRQ_Handler)
{
	rsvp_u8_t channum;
	
    /* Read interrupt status registers */
    adc_1_irq_status = ADC_1_SAR_INTR_MASKED_REG;
    /* Check for End of Scan interrupt */
    if((adc_1_irq_status & ADC_1_EOS_MASK) != 0u)
    {
		/* not doing anything with range detect/saturation right now... */
        /* Read range interrupt status and raise the flag */
        adc_1_range_flag = ADC_1_SAR_RANGE_INTR_MASKED_REG;
        /* Clear range detect status */
        ADC_1_SAR_RANGE_INTR_REG = adc_1_range_flag;
		for (channum = 0; channum < ADC_1_TOTAL_CHANNELS_NUM; channum++){
          /* Buffer the results */
            adc_1_data[channum] = ADC_1_GetResult16(channum);
        }		
        /* set IRQ done flag */
        adc_1_irq_flag = 1u;
    }
	/* test for injection channel */
	if((adc_1_irq_status  & ADC_1_INJ_EOC_MASK) != 0u)
    {
        adc_1_data[4] = ADC_1_GetResult16(4);
    }    

    /* Clear handled interrupt */
    ADC_1_SAR_INTR_REG = adc_1_irq_status;
}
#endif

#if defined(RSVP_USE_USER_SW)
CY_ISR_PROTO(USER_SW_IRQ_Handler);
rsvp_u32_t  user_sw_1_irq_status                   = 0u;
rsvp_u8_t   user_sw_1_irq_flag                     = 0u;

/**
  * @fn         void USER_SW_1_IRQ_Handler(void)
  * @brief      Interrupt Service Routine for the USER_SW_1 Component
  * @param      void
  * @retval     void
  */
CY_ISR(USER_SW_1_IRQ_Handler)
{
	/* Read interrupt source registers */
    /* user_sw_1_irq_status = USER_SW_1_GetPending(); */
	
	if (user_sw_1_irq_flag != 0)
	USER_LED_3_Write(!USER_LED_3_Read());
	
	/* use SW_1 to enable /get CLI running */
	rsvp_CLI_NewPrompt = TRUE;
    rsvp_CLI_Enable = TRUE;

	/* increment the interrupt timer flag  */
	/* (the number of times the interrupt has occurred) */
	user_sw_1_irq_flag++;

	/* Clear handled interrupt */
	/* USER_SW_1_ClearInterrupt(); */
	/* USER_SW_1_IRQ_ClearPending(); */
}
#endif


/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of rsvp_interrupts.c */
