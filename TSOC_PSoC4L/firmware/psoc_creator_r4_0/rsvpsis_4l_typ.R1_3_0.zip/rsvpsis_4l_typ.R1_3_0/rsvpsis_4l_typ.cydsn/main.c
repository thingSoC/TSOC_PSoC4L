/**
 ******************************************************************************
    @file        main.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the Main program entry point/function.
    @mainpage    RSVP Platform Firmware Documentation
    @section     main_intro Introduction
    @par
    \n
      The main function performs the following actions:
    \n
     1. Starts the RSVPSIS platform code: 
        which in turn, starts and initializes each of the 
        components(pages) that are "enabled" in the TopDesign.cysch file.
        This typically includes the external pin definitions for that page.
        The initialization code as compiler guards to omit code sections
        that reference the disabled, components(pages).
        
        A) Clocks, Timers, and Systick are selectively started
        B) The USBFS HID Bootloader is started, and runs for ten (10) seconds,
           giving the user time to engage the Cypress Host Bootloader program.
        C) After ten (10) seconds of inactivity, the USBFS HID Bootloader
           starts the application program.
        D) The application program is the basic RSVPSIS platform,
           which starts the USBFS component as a CDC (USBUART) device,
           and starts the Command Line Interpretor (RSVP_CLI),
           if it has been enabled in the "rsvp_conf.h" file.
  
     2. The main loop runs the RSVPSIS platform code:
        which in turn, calls each of the components(pages) "run" function,
        if any foreground processing is needed by that component. 
        Most data movement, and any control flag processing 
        occurs in the interrupt context, in the background.
        An interrupt driven state machine is implemented for those
        components requiring additonal data and control functions.  
    \n
        More RSPVISIS Documentation at : http://www.rsvpsis.com
    \n
    @par
    @section    main_theory Theory of Operation
    @par
    \n
    @par
    @section    main_packages Firmware Packages 
    @par
    The RSVP Firmware utilizes several external software packages \n
	with various licenses. Check each package for redistribution terms. \n
    @par
    \n
	@par
	Cypress Creator Compiler/Libraries : \n
	GCC/Keil Compiler/Libraries : \n
	TBD: (audit any other third-party code for licensing terms) \n
	@par

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/

#include <project.h>

#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_platform.h>
#include <rsvp_adc.h>
#include <rsvp_cli.h>
#include <rsvp_io.h>
#include <rsvp_ringbuf.h>
#include "stdio.h"

/*-----------------------------------------------------------------------------*/
/** @defgroup main main
  * @{
  */
#define RSVP_DEBUG 1 /**< Define to a nonzero value to enable debugging messages */
#define RSVP_TEST  0 /**< Define to a nonzero value to enable test/assert modes  */

/*-----------------------------------------------------------------------------*/
/**
  * @fn         int main(void)
  * @brief      Firmware Main Entry Point
  * @brief      The main entry point
  * @param      None.
  * @retval     int (Main never returns, a return of int is used to indicate failure)
  */
int main()
{
    /* Start the RSVPSIS platform code */
    rsvp_RetCode_t rsvp_RetVal;
    if ((rsvp_RetVal = rsvp_platform_Start()) != RSVP_SUCCESS) {
       rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nRSVP:ERROR Platform Start Failed!\r\n");
    }

    for(;;)
    {       
      /* Run the RSVPSIS state machines... */
      if ((rsvp_RetVal = rsvp_platform_Run()) != RSVP_SUCCESS) {
        rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nRSVP:ERROR Platform Run Failed!\r\n");
      }
      /* -------------------------------------- */   
      /* Add your new main loop code below here */
      /* -------------------------------------- */
    }
}
/* [] END OF FILE */