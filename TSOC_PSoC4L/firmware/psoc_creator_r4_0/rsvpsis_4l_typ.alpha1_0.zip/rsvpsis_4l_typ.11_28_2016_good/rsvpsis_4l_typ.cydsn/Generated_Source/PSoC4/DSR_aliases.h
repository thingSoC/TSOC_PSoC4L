/*******************************************************************************
* File Name: DSR.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DSR_ALIASES_H) /* Pins DSR_ALIASES_H */
#define CY_PINS_DSR_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define DSR_0			(DSR__0__PC)
#define DSR_0_PS		(DSR__0__PS)
#define DSR_0_PC		(DSR__0__PC)
#define DSR_0_DR		(DSR__0__DR)
#define DSR_0_SHIFT	(DSR__0__SHIFT)
#define DSR_0_INTR	((uint16)((uint16)0x0003u << (DSR__0__SHIFT*2u)))

#define DSR_INTR_ALL	 ((uint16)(DSR_0_INTR))


#endif /* End Pins DSR_ALIASES_H */


/* [] END OF FILE */
