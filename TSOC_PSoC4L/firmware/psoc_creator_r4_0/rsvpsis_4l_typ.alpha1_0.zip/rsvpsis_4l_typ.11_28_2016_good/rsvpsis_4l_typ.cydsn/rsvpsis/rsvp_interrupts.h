/**
  ******************************************************************************
  *
  * @file        rsvp_interrupts.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define all the base interrupt service routines (ISR's)
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_INTERRUPTS_H_
#define RSVP_INTERRUPTS_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include <cydisabledsheets.h>

/** @addtogroup rsvp_platform rsvp_platform
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Types
  * @{
  */


/**
  * Close the Doxygen rsvp_platform__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Constants
  * @{
  */


/**
  * Close the Doxygen rsvp_platform_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Macros
  * @{
  */
#define ENTER_CRITICAL_SECTION( ) ({cpu_irq_status = CyEnterCriticalSection();})  
#define EXIT_CRITICAL_SECTION( )  ({CyExitCriticalSection(cpu_irq_status);})  

/**
  * Close the Doxygen rsvp_platform_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Variables
  * @{
  */

/**
  * Close the Doxygen rsvp_platform_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Functions
  * @{
  */
extern rsvp_u8_t   cpu_irq_status;
extern rsvp_u8_t   cpu_irq_flag;

#if (RSVP_USE_LVDT_1 == TRUE)
extern rsvp_u32_t  lvdt_1_irq_status;
extern rsvp_u8_t   lvdt_irq_flag;
extern CY_ISR_PROTO(LVDT_1_IRQ_Handler);
extern void LVDT_1_StartEx(cyisraddress address);
#endif

#if (RSVP_USE_WDT_1 == TRUE)
extern rsvp_u32_t   wdt_1_irq_status;
extern rsvp_u8_t    wdt_irq_flag;
extern CY_ISR_PROTO(WDT_1_IRQ_Handler);
extern void WDT_1_StartEx(cyisraddress address);
#endif

#if (RSVP_USE_SYSTICK == TRUE)
extern rsvp_u32_t  systick_irq_status;
extern rsvp_u32_t  systick_irq_flag;
extern rsvp_u32_t  systick_blink_flag;
extern CY_ISR_PROTO(SysTick_IRQ_Handler);
extern void SysTick_StartEx(cyisraddress address);
#endif

#if (RSVP_USE_TIMER_1 == TRUE)
extern rsvp_u32_t  timer_1_irq_status;
extern rsvp_u8_t   timer_1_irq_flag;
extern CY_ISR_PROTO(TIMER_1_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_2 == TRUE)
extern rsvp_u32_t  timer_2_irq_status;
extern rsvp_u8_t   timer_2_irq_flag;
extern CY_ISR_PROTO(TIMER_2_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_3 == TRUE)
extern rsvp_u32_t  timer_3_irq_status;
extern rsvp_u8_t   timer_3_irq_flag;
extern CY_ISR_PROTO(TIMER_3_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_4 == TRUE)
extern rsvp_u32_t  timer_4_irq_status;
extern rsvp_u8_t   timer_4_irq_flag;
extern CY_ISR_PROTO(TIMER_4_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_5 == TRUE)
extern rsvp_u32_t  timer_5_irq_status;
extern rsvp_u8_t   timer_5_irq_flag;
extern CY_ISR_PROTO(TIMER_5_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_6 == TRUE)
extern rsvp_u32_t  timer_6_irq_status;
extern rsvp_u8_t   timer_6_irq_flag;
extern CY_ISR_PROTO(TIMER_6_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_7 == TRUE)
extern rsvp_u32_t  timer_7_irq_status;
extern rsvp_u8_t   timer_7_irq_flag;
extern CY_ISR_PROTO(TIMER_7_IRQ_Handler);
#endif

#if (RSVP_USE_TIMER_8 == TRUE)
extern rsvp_u32_t  timer_8_irq_status;
extern rsvp_u8_t   timer_8_irq_flag;
extern CY_ISR_PROTO(TIMER_8_IRQ_Handler);
#endif

#if (RSVP_USE_I2C_1 == TRUE)
  /* placeholder - I2C operations/interrupts are internal */
#endif

#if (RSVP_USE_UART_1 == TRUE)
extern rsvp_u32_t  uart_1_rx_irq_status;
extern rsvp_u8_t   uart_1_rx_irq_flag;
extern rsvp_u32_t  uart_1_tx_irq_status;
extern rsvp_u8_t   uart_1_tx_irq_flag;
    #if defined(CY_ISR_UART_1_RX_IRQ_H)
        extern CY_ISR_PROTO(UART_1_RX_IRQ_Handler);
    #endif
#endif

#if (RSVP_USE_UART_2 == TRUE)
extern rsvp_u8_t   uart_2_rx_irq_status;
extern rsvp_u8_t   uart_2_rx_irq_flag;
extern rsvp_u8_t   uart_2_tx_irq_status;
extern rsvp_u8_t   uart_2_tx_irq_flag;
    #if defined(CY_ISR_UART_2_RX_IRQ_H)
        extern CY_ISR_PROTO(UART_2_RX_IRQ_Handler);
    #endif
#endif

#if (RSVP_USE_CMP_1 == TRUE)
extern rsvp_u32_t  cmp_1_irq_status;
extern rsvp_u8_t   cmp_1_irq_flag;
extern CY_ISR_PROTO(CMP_1_IRQ_Handler);
#endif

#if (RSVP_USE_CMP_2 == TRUE)
extern rsvp_u32_t  cmp_2_irq_status;
extern rsvp_u8_t   cmp_2_irq_flag;
extern CY_ISR_PROTO(CMP_2_IRQ_Handler);
#endif

#if (RSVP_USE_ADC_1 == TRUE)
extern rsvp_u32_t  adc_1_irq_status;
extern rsvp_u8_t   adc_1_irq_flag;
extern rsvp_u8_t   adc_1_range_status;
extern rsvp_u8_t   adc_1_ready_flag;
extern rsvp_u8_t   adc_1_range_flag;
extern rsvp_s32_t  adc_1_gain;
extern rsvp_s16_t  adc_1_data[32];
extern CY_ISR_PROTO(ADC_1_IRQ_Handler);
#endif 

#if (RSVP_USE_USER_SW == TRUE)
extern rsvp_u32_t  user_sw_1_irq_status;
extern rsvp_u8_t   user_sw_1_irq_flag;
extern CY_ISR_PROTO(USER_SW_1_IRQ_Handler);
#endif

/**
  * Close the Doxygen rsvp_interrupts_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_INTERRUPTS_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_interrupts group.
  *    @}
*/
