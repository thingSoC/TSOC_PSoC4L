/**
  ******************************************************************************
  *
  * @file        rsvp_platform.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define all the platform peripherals and devices
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_PLATFORM_H_
#define RSVP_PLATFORM_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include "stdio.h"
#include "string.h"

/** @addtogroup rsvp_platform rsvp_platform
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Types
  * @{
  */

/**
  * Close the Doxygen rsvp_platform__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Constants
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* LED definitions                                                             */
/*-----------------------------------------------------------------------------*/
#define RSVP_LED_ON             		(1u)
#define RSVP_LED_OFF            		(0u)
#define RSVP_LED_OFF_MASK       		0x00
#define RSVP_LED_RED_MASK       		0x01
#define RSVP_LED_RED_CHANNUM    		0x00
#define RSVP_LED_GREEN_MASK     		0x02
#define RSVP_LED_GREEN_CHANNUM  		0x01
#define RSVP_LED_BLUE_MASK      		0x04
#define RSVP_LED_BLUE_CHANNUM   		0x02
#define RSVP_LED_YELLOW_MASK      		0x08
#define RSVP_LED_YELLOW_CHANNUM   		0x04

/** Some basic/misc constants */
#define LOW                             (0u)
#define HIGH                            (1u)

/* Modbus UART Definitions                                                    */
#define UART_2_FIFO_DEPTH            	8

/**
  * Close the Doxygen rsvp_platform_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_platform_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Variables
  * @{
  */

/** Platform Globals */

/**
  * Close the Doxygen rsvp_platform_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_platform_Exported_Functions
  * @{
  */
extern rsvp_RetCode_t rsvp_platform_Start(void);
extern rsvp_RetCode_t rsvp_platform_Stop(void);
extern rsvp_RetCode_t rsvp_platform_Run(void);
extern rsvp_RetCode_t rsvp_platform_Sleep(void);
extern rsvp_RetCode_t rsvp_platform_Wake(void);

/**
  * Close the Doxygen rsvp_platform_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_PLATFORM_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_platform group.
  *    @}
*/
