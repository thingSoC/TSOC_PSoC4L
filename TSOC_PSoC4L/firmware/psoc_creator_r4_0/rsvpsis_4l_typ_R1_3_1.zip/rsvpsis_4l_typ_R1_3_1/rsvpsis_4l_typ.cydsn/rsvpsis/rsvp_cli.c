/**
 ******************************************************************************
    @file        rsvp_cli.c
    @author      Tom Moxon (www.rsvpsis.com)
    @version     1.3.0
    @copyright   Moxon Design
    @brief       This file provides the command line interpretor functions.
    @section     rsvp_cli_intro rsvp_adc hardware routines
    @par	
    @section    rsvp_cli_theory Theory of Operation
    @par
    theory \n
	@par
    more \n

 ******************************************************************************
*/
/*****************************************************************************
# Copyright:	(C) 2001-2012 by RSVPSIS. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*****************************************************************************
* RSVP Command Line Interface Definitions
******************************************************************************
*
* Description:
* This file describes the set of capabilities provided 
* for RSVP Command Line Interface (rsvp_CLI).
*
*****************************************************************************/
#include <project.h>

#include "rsvp_types.h"
#include "rsvp_conf.h"
#include "rsvp_interrupts.h"
#include "rsvp_platform.h"
#include "rsvp_cli.h"
#include "rsvp_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*****************************************************************************
* RSVP Command Line Interface Global Variable Defintions
*****************************************************************************/

const tRsVpCmdArray vCommandTable[] = 
{
	{"commands", rsvp_CLI_CmdCOMMAND,	 ": Show list of CLI Commands"},
    {"connect",	 rsvp_CLI_CmdConnect,    " : connect X Y - connect channel X and Y"},	
	{"console",	 rsvp_CLI_CmdConsole,	 " : console X - switch console to channel X"},
	{"echo",	 rsvp_CLI_CmdEcho,		 "    : echo - Echo whatever command line you type (i.e. argv[])"},	
	{"info",     rsvp_CLI_CmdINFO,		 "    : info - return server information"},
	{"ping",     rsvp_CLI_CmdPING,		 "    : ping - pong"},
	{"test",	 rsvp_CLI_CmdTest,		 "    : test CMD - invoke test command CMD "},	
   {0, 0, 0 }
};
/* variable for number of commands (MAX=255) in command table (in FLASH)    */
rsvp_u8_t bNumCmd = sizeof(vCommandTable)/sizeof(*vCommandTable);

char StrBuf[64] = "                                                      ";
rsvp_u8_t StrBufLen;

rsvp_u8_t rsvp_CLI_Channel = RSVP_CLI_CHANNEL;
rsvp_u8_t rsvp_CLI_NewPrompt = TRUE;
rsvp_u8_t rsvp_CLI_Enable = TRUE;

/*****************************************************************************
* RSVP Command Line Interface API Defintions
*****************************************************************************/
rsvp_RetCode_t
rsvp_CLI_CmdProcess(char *pcCmdBuffer)
{
    static char *argv[RSVP_CLI_ARGC_MAX + 1];
    char *pcChar;
    int argc;
    int bFoundArgv = 1;
    const tRsVpCmdArray *pCmdEntry;
    rsvp_RetCode_t RetCode;
	
    /* point to the first character of the command line buffer */
    pcChar = pcCmdBuffer;
    /* reset the argument counter */
    argc = 0;
    
    /* loop through the command line buffer until the null terminator is encountered */
    while(*pcChar)
    {
        /* If there is a space, then replace it with a zero, and set the flag to search for the next argument */
        if(*pcChar == ' ')
        {
            *pcChar = 0;
            bFoundArgv = 1;
        }
        /* Otherwise it is not a space, so it must be a character that is part of an argument */
        else
        {
            /* If bFoundArgv is set, then that means we are looking for the start of the next argument */
            if(bFoundArgv)
            {
                /* As long as the maximum number of arguments has not been
                   reached, then save the pointer to the start of this new arg
                   in the argv array, and increment the count of args, argc. 
                */
                if(argc < RSVP_CLI_ARGC_MAX)
                {
                    argv[argc] = pcChar;
                    argc++;
                    bFoundArgv = 0;
                }

                // The maximum number of arguments has been reached so return the error */
                else
                {
					rsvp_CLI_NewPrompt = TRUE;
                    return(RSVP_ILL_ARG);
                }
            }
        }

        /* Advance to the next character in the command line */
        pcChar++;
    }

    /* If one or more arguments was found, then process the command */
    if(argc)
    {
        /* Start at the beginning of the command table, to look for a matching command */
        pCmdEntry = &vCommandTable[0];

        /* Search through the command table until a null command string is found, which marks the end of the table */
        while(pCmdEntry->pcRsVpCmdName)
        {

            /* If this command entry command string matches argv[0], then call
               the function for this command, passing the command line
               arguments.
            */
            if(!strcmp(argv[0], pCmdEntry->pcRsVpCmdName))
            {
                RetCode = pCmdEntry->pfnRsVpFunction(argc, argv);
				rsvp_CLI_NewPrompt = TRUE;
				return(RetCode);
            }
            /* Not found, so advance to the next entry */
            pCmdEntry++;
        }
    }

    /* Fall through to here means that no matching command was found, so return an error */
    rsvp_CLI_CmdError(argc, argv);
    return(RSVP_ERR_PLATFORM);
}


/*****************************************************************************
* RSVP Command Line Interface - Command API Defintions
*****************************************************************************/
rsvp_RetCode_t 
rsvp_CLI_CmdCOMMAND(int argc, char *argv[]) {
    (void) (argc);
    (void) (*argv);
	
        /* Count of commands tested */
		rsvp_u8_t cmdcnt;
        
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r");
		for ( cmdcnt = 0; cmdcnt < (bNumCmd-1); cmdcnt++ ) 
		{
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdName);
            rsvp_io_PutString(rsvp_CLI_Channel,  "    ");
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdHelp);
			rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		}	
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdError(int argc, char *argv[])
{
    (void) (argc);
    (void) (*argv);
	    /* Unrecognized Command Line Entered */
	    rsvp_io_PutString(rsvp_CLI_Channel,  "\r-ERROR Unknown COMMAND\r\n>");
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdConsole(int argc, char *argv[])
{
	rsvp_u8_t  Console_ChanNum = 1;

    if (argc > 1 ) {
	   Console_ChanNum = (rsvp_u8_t) atoi(argv[1]);
	}
	if (Console_ChanNum == 0) {
       rsvp_CLI_NewPrompt = TRUE;
	} else if (Console_ChanNum == 255) {
       rsvp_CLI_NewPrompt = FALSE;
       rsvp_CLI_Enable = FALSE;
	   Console_ChanNum = 1;
	} else if (Console_ChanNum > 2) {
	  Console_ChanNum = 1;
	}
    ENTER_CRITICAL_SECTION( );
	rsvp_CLI_Channel = Console_ChanNum;
    EXIT_CRITICAL_SECTION( );
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdEcho(int argc, char *argv[])
{
	rsvp_u8_t i;

	rsvp_io_PutString(rsvp_CLI_Channel,  " \r");
	for (i = 1; i < argc; i++)
	{
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[i]);
		rsvp_io_PutString(rsvp_CLI_Channel,  " ");
	}
	rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdADCChannel(int argc, char *argv[])
{
    rsvp_u8_t  ADC_ChanNum = 0;
	int tmp = 0;
	char str_tmp_Buffer[10] = "        ";

	/* Test Argc (number of arguments) */
    if (argc < 3) {
		return(RSVP_ILL_ARG);
	}

	ADC_ChanNum = (rsvp_u8_t) atoi(argv[2]);
    if ((argc == 3) && (strcmp( "?", argv[2] ) == 0)) {	
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nADC Channel = ");
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
		rsvp_io_PutString(rsvp_CLI_Channel,  ",  ADC Data = ");
		tmp = (int) adc_1_data[ADC_ChanNum];
		rsvp_CLI_itoa(str_tmp_Buffer, tmp, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n\r\n");
    }
	return(RSVP_SUCCESS);
}

char* rsvp_CLI_itoa(char* result, int value, int base) 
{
		/* test if the base parameter is valid */
		if (base < 2 || base > 36) { *result = '\0'; return result; }
	
		char* ptr = result, *ptr1 = result, tmp_char;
		int tmp_value;
	
		do {
			tmp_value = value;
			value /= base;
			*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
		} while ( value );
	
		/* insert negative sign if applicable */
		if (tmp_value < 0) *ptr++ = '-';
		*ptr-- = '\0';
		while(ptr1 < ptr) {
			tmp_char = *ptr;
			*ptr--= *ptr1;
			*ptr1++ = tmp_char;
		}
		return result;
}

rsvp_RetCode_t
rsvp_CLI_CmdConnect(int argc, char *argv[])
{
    rsvp_u8_t X, Y, X_len, Y_len, X_buf, Y_buf;
    rsvp_u8_t wire_break = 1;
    
    if (argc > 2 ) {
	  X = (rsvp_u8_t) atoi(argv[1]);
	  Y = (rsvp_u8_t) atoi(argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n Connecting Channel ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " to Channel  ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " : Press User Switch to Return to RSVP_CLI\r\n");
    
      /* wire the channels until a break is detected */
      while (wire_break != 0) {
          X_len = rsvp_io_GetRxBufferSize(X);
          if (X_len != 0) {
              X_buf = rsvp_io_GetChar(X);
              rsvp_io_PutChar(Y, X_buf);
          }
          Y_len = rsvp_io_GetRxBufferSize(Y);
          if (Y_len != 0) {
              Y_buf = rsvp_io_GetChar(Y);
              rsvp_io_PutChar(X, Y_buf);
          }
          #if defined(RSVP_USE_USER_SW)
            wire_break = USER_SW_1_Read();
          #endif
      }
	}
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdTest(int argc, char *argv[])
{
	if (argc > 1 ) {
	if ((strcmp( "adc", argv[1] ) == 0)) {
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
      #if defined(RSVP_USE_ADC_1)
	    rsvp_u16_t  channum, chandata;
	    char str_tmp_Buffer[10] = "        ";
	    for (channum = 0; channum < ADC_1_TOTAL_CHANNELS_NUM; channum++){
		  rsvp_CLI_itoa(str_tmp_Buffer, channum, 10); 
		  rsvp_io_PutString(rsvp_CLI_Channel,  "ADC Channel = ");
		  rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		  rsvp_io_PutString(rsvp_CLI_Channel,  ",  ADC Data = ");
		  chandata = (int) adc_1_data[channum];
          if (chandata > 4096) {
            /* clip underflow */
            chandata = 0;
          }
		  rsvp_CLI_itoa(str_tmp_Buffer, chandata, 10); 
		  rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n"); 
	    }
      #endif
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
	} else if ((strcmp( "led", argv[1] ) == 0)) { 
	  rsvp_io_PutString(rsvp_CLI_Channel, "\r\n test led : test LEDs (blink on/off)\r\n");	
      USER_LED_1_Write(RSVP_LED_ON);
	  USER_LED_2_Write(RSVP_LED_ON);
	  USER_LED_3_Write(RSVP_LED_ON);
      CyDelay(1000);
      USER_LED_1_Write(RSVP_LED_OFF);
	  USER_LED_2_Write(RSVP_LED_OFF);
	  USER_LED_3_Write(RSVP_LED_OFF);
      CyDelay(1000);
    } else if ((strcmp( "self", argv[1] ) == 0)) {
		/* stubbed for space - restore full self test code here */
		rsvp_io_PutString(rsvp_CLI_Channel, "test self : self test not implemented yet... \r\n\r\n");
        CyDelay(200);
    } else if ((strcmp( "uart", argv[1] ) == 0)) {
		rsvp_io_PutString(1, "uart channel #1 : 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \r\n\r\n");
		rsvp_io_PutString(2, "uart channel #2 : 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \r\n\r\n");
        CyDelay(200);
	} else if ((strcmp( "boot", argv[1] ) == 0)) {
		rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : entering the boot loader program for firmware update!");	
		rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : (exit the terminal app and start the Bootloader Host app!) \r\n\r\n");	
        CyDelay(200);
        #if !defined BOOTLD_PG__DISABLED
          Bootloadable_Load();
        #endif
	}
  }
  return(RSVP_SUCCESS);
}

void rsvp_CLI_Poll(void) 
{
  rsvp_u8_t StringLen;
	
  #if (RSVP_USE_CLI == TRUE)
	if (rsvp_CLI_Enable == TRUE) {
      /* send the command line prompt */
	  if (rsvp_CLI_NewPrompt == TRUE ) {
        rsvp_io_PutString(rsvp_CLI_Channel, "> ");
	    rsvp_CLI_NewPrompt = FALSE;
	  }
     
      /* Don't block unless some characters are entered ... */
      StringLen = rsvp_io_GetRxBufferSize(rsvp_CLI_Channel);
      if (StringLen != 0 ) {
          /* Block until a command is entered and returned */
          StringLen = rsvp_io_GetString(rsvp_CLI_Channel, &StrBuf[0], 64);
      }
	
      /* Pass the line to the Command Line Interpreter */
      /* if there more than a zero length - i.e. more than a delimiter? */
      if( StringLen != 0 ) 
	  {
		/* parse and execute the command line */
        rsvp_CLI_CmdProcess(&StrBuf[0]);
	  }
	}
  #endif
}

rsvp_RetCode_t 
rsvp_CLI_CmdINFO(int argc, char *argv[]) {
    (void) (argc);
    (void) (*argv);
      rsvp_io_PutString(rsvp_CLI_Channel, "\r\n");
      rsvp_io_PutString(rsvp_CLI_Channel, RSVP_NAME);
      rsvp_io_PutString(rsvp_CLI_Channel, " ");
      rsvp_io_PutString(rsvp_CLI_Channel, RSVP_VERSION);
      rsvp_io_PutString(rsvp_CLI_Channel, "\r\n");
      return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdPING(int argc, char *argv[])
{
    (void) argc;
    (void) argv;
	rsvp_io_PutString(rsvp_CLI_Channel,  "\r+PONG\r\n");
	return(RSVP_SUCCESS);
}

/****************************************************************************/
/* End of File : rsvp_cli.c */
