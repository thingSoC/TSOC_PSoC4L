/*****************************************************************************
  *
  * @file        rsvp_cli.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       RSVPSIS Command Line Interpretor
  */
/*****************************************************************************
# Copyright:	(C) 2001-2016 by RSVPSIS. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/
/*--------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                    */
/*--------------------------------------------------------------------------*/
#ifndef __RSVP_CLI_H__
#define __RSVP_CLI_H__

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_conf.h>
#include <rsvp_types.h>
#include <rsvp_interrupts.h>
#include <CyLib.h>
#include <cydevice_trm.h>
#include "stdio.h"
#include "string.h"

/*--------------------------------------------------------------------------*/
/* RSVP CLI Defines                                                              */
/*--------------------------------------------------------------------------*/
#ifndef RSVP_CLI_ARGC_MAX
#define RSVP_CLI_ARGC_MAX        8
#endif

#ifndef RSVP_CLI_CHANNEL
#define RSVP_CLI_CHANNEL         1
#endif

#define RSVP_SUCCESS	         (0)
#define RSVP_ERR_PLATFORM		(-1)
#define RSVP_ILL_ARG		    (-2)

typedef rsvp_RetCode_t (*pfnRsVpCmdFunc)(int argc, char *argv[]);

typedef struct {
	const char *pcRsVpCmdName;
	pfnRsVpCmdFunc pfnRsVpFunction;
    const char *pcRsVpCmdHelp;
} tRsVpCmdArray;

typedef struct {
	const char *RsVpKeyName;        /* KeyName - device objects start with a "/" */
	pfnRsVpCmdFunc RsVpKeyFunction; /* KeyFunction - pointer to the key handler function */
    rsvp_cu8_t RsVpKeyValType;      /* KeyValType - type of the key value : Integer, String, etc. */
    rsvp_cu8_t RsVpKeyValLen;       /* KeyValLen - length of the key value in bytes */
    rsvp_cu8_t RsVpKeyTTL;          /* KeyTTL - Key time to live in seconds : 0 = dead */
    const char *RsVpKeyIPSO;        /* KeyIPSO - IPSO assigned KeyName */
} tRsVpKeyArray;


extern rsvp_u8_t rsvp_CLI_Channel;
extern rsvp_u8_t rsvp_CLI_NewPrompt;
extern rsvp_u8_t rsvp_CLI_Enable;
	
/*--------------------------------------------------------------------------*/
/*  RSVP CLI API Functions                                                  */
/*--------------------------------------------------------------------------*/
extern void            rsvp_CLI_Poll(void);

extern rsvp_RetCode_t  rsvp_CLI_CmdINFO(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdPING(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdCOMMAND(int argc, char *argv[]);

extern rsvp_RetCode_t  rsvp_CLI_CmdADCChannel(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdProcess(char *pcCmdBuffer);
extern rsvp_RetCode_t  rsvp_CLI_CmdError(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdEcho(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdTest(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdConnect(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdConsole(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_CLI_CmdADC_AMUX(int argc, char *argv[]);

extern char*           rsvp_CLI_itoa(char* result, int value, int base);
/*--------------------------------------------------------------------------*/
#ifdef __cplusplus
} 
#endif /* __cplusplus */

#endif /* __RSVP_CLI_H__ */
/* End of File : RSVP_CLI.h */
