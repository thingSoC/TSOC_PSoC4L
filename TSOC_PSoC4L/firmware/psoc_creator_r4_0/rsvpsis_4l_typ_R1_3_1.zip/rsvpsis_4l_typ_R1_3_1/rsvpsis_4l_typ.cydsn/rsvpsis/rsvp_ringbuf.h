/**
  ******************************************************************************
  *
  * @file        rsvp_io.h
  * @author      Tom Moxon (www.rsvpsis.com)
  * @version     1.3.0
  * @copyright   Moxon Design
  * @brief       The include file to define all the Analog-to-Digital Converter routines
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef __RSVP_RINGBUF_H__
#define __RSVP_RINGBUF_H__

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

#include <project.h>
#include <rsvp_types.h>
#include <CyLib.h>
#include <cydevice_trm.h>

//*****************************************************************************
//
// The structure used for encapsulating all the items associated with a
// ring buffer.
//
//*****************************************************************************
typedef struct
{
    rsvp_u32_t Buf_Size; /* ring buffer size */
    volatile rsvp_u32_t Buf_WriteIndex; /* ring buffer write index  */
    volatile rsvp_u32_t Buf_ReadIndex; /* ring buffer read index */
   unsigned char *Buf; /* ring buffer itself */
}
rsvp_RingBuf_t;

//*****************************************************************************
//
// API Function prototypes
//
//*****************************************************************************
extern void       rsvp_RingBufInit(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size);
extern bool       rsvp_isRingBufFull(rsvp_RingBuf_t *RingBuf_s);
extern bool       rsvp_isRingBufEmpty(rsvp_RingBuf_t *RingBuf_s);
extern void       rsvp_RingBufFlush(rsvp_RingBuf_t *RingBuf_s);
extern rsvp_u32_t rsvp_RingBufUsed(rsvp_RingBuf_t *RingBuf_s);
extern rsvp_u32_t rsvp_RingBufFree(rsvp_RingBuf_t *RingBuf_s);
extern rsvp_u32_t rsvp_RingBufSize(rsvp_RingBuf_t *RingBuf_s);
extern rsvp_u8_t  rsvp_RingBufReadOne(rsvp_RingBuf_t *RingBuf_s);
extern void       rsvp_RingBufRead(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size);
extern void       rsvp_RingBufWriteOne(rsvp_RingBuf_t *RingBuf_s, unsigned char Buf);
extern void       rsvp_RingBufWrite(rsvp_RingBuf_t *RingBuf_s, unsigned char *Buf, rsvp_u32_t Buf_Size);
/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif //  __RSVP_RINGBUF_H__
